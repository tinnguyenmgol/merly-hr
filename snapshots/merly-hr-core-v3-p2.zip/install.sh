#!/bin/sh
set -eu
PKG=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=${MERLY_ROOT:-$(dirname "$PKG")}
ROOT=$(CDPATH= cd -- "$ROOT" && pwd)
TS=$(date +%Y%m%d_%H%M%S)
BACK="$ROOT/private/backups/core_v3_p2_$TS"
MISSING="$BACK/.missing"
FILES="private/core/AuditLog.php private/governance/policy.php private/governance/ConfigVault.php private/governance/PayrollGovernance.php private/governance/Health.php private/cron/governance_guard.php private/cron/governance_config_backup.php private/tools/governance_backup.php private/tools/governance_restore.php private/tools/payroll_lock_month.php private/tools/payroll_unlock_month.php private/tools/payroll_mark_paid.php private/tools/payroll_month_close.php private/jobs/jobs_config.php private/ux/ActionCenter.php public_html/api/healthz.php public_html/hr/governance.php public_html/hr/_master_nav.php public_html/hr/assets/p2.css"
BACKED=0
rollback(){ rc=$?; if [ "$rc" -ne 0 ] && [ "$BACKED" -eq 1 ]; then echo "INSTALL FAIL -> rollback"; for rel in $FILES; do if grep -Fxq "$rel" "$MISSING" 2>/dev/null; then rm -f "$ROOT/$rel"; elif [ -f "$BACK/$rel" ]; then mkdir -p "$ROOT/$(dirname "$rel")"; cp "$BACK/$rel" "$ROOT/$rel"; fi; done; rm -f "$ROOT/private/jobs/jobs_config.php.p2tmp"; echo "ROLLBACK OK: $BACK"; fi; exit "$rc"; }
trap rollback EXIT INT TERM

echo "[1/11] Validate Core v3 P0 + P1..."
test -f "$ROOT/private/core/bootstrap.php"
test -f "$ROOT/private/core/Queue.php"
test -f "$ROOT/private/jobs/jobs_config.php"
test -f "$ROOT/private/payroll/payroll_engine.php"
test -f "$ROOT/private/ux/ActionCenter.php"
test -f "$ROOT/public_html/hr/_master_nav.php"
test -f "$PKG/private/governance/Health.php"

echo "[2/11] Verify package structure + syntax..."
test -f "$PKG/README.txt"
for f in "$PKG"/private/core/*.php "$PKG"/private/governance/*.php "$PKG"/private/cron/*.php "$PKG"/private/tools/*.php "$PKG"/private/ux/*.php "$PKG"/public_html/api/*.php "$PKG"/public_html/hr/*.php; do /usr/bin/php -l "$f"; done

echo "[3/11] Backup production targets..."
mkdir -p "$BACK"; : > "$MISSING"
for rel in $FILES; do if [ -f "$ROOT/$rel" ]; then mkdir -p "$BACK/$(dirname "$rel")"; cp "$ROOT/$rel" "$BACK/$rel"; else echo "$rel" >> "$MISSING"; fi; done
BACKED=1

echo "[4/11] Install Governance core..."
mkdir -p "$ROOT/private/governance" "$ROOT/private/governance/audit" "$ROOT/private/governance/state" "$ROOT/private/governance/config_backups" "$ROOT/private/cron" "$ROOT/private/tools" "$ROOT/public_html/api" "$ROOT/public_html/hr/assets"
chmod 700 "$ROOT/private/governance" "$ROOT/private/governance/audit" "$ROOT/private/governance/state" "$ROOT/private/governance/config_backups" 2>/dev/null || true
cp "$PKG/private/core/AuditLog.php" "$ROOT/private/core/AuditLog.php"
for f in policy.php ConfigVault.php PayrollGovernance.php Health.php; do cp "$PKG/private/governance/$f" "$ROOT/private/governance/$f"; done
for f in governance_guard.php governance_config_backup.php; do cp "$PKG/private/cron/$f" "$ROOT/private/cron/$f"; done
for f in governance_backup.php governance_restore.php payroll_lock_month.php payroll_unlock_month.php payroll_mark_paid.php payroll_month_close.php; do cp "$PKG/private/tools/$f" "$ROOT/private/tools/$f"; done
cp "$PKG/private/ux/ActionCenter.php" "$ROOT/private/ux/ActionCenter.php"
cp "$PKG/public_html/api/healthz.php" "$ROOT/public_html/api/healthz.php"
cp "$PKG/public_html/hr/governance.php" "$ROOT/public_html/hr/governance.php"
cp "$PKG/public_html/hr/_master_nav.php" "$ROOT/public_html/hr/_master_nav.php"
cp "$PKG/public_html/hr/assets/p2.css" "$ROOT/public_html/hr/assets/p2.css"

echo "[5/11] Register governance jobs through existing Job Runner..."
MERLY_ROOT="$ROOT" /usr/bin/php "$PKG/private/tools/register_governance_jobs.php"
/usr/bin/php -l "$ROOT/private/jobs/jobs_config.php.p2tmp"
mv "$ROOT/private/jobs/jobs_config.php.p2tmp" "$ROOT/private/jobs/jobs_config.php"

echo "[6/11] Production syntax + no hardcoded home path..."
for f in "$ROOT/private/core/AuditLog.php" "$ROOT"/private/governance/*.php "$ROOT/private/cron/governance_guard.php" "$ROOT/private/cron/governance_config_backup.php" "$ROOT/private/tools/governance_backup.php" "$ROOT/private/tools/governance_restore.php" "$ROOT/private/tools/payroll_lock_month.php" "$ROOT/private/tools/payroll_unlock_month.php" "$ROOT/private/tools/payroll_mark_paid.php" "$ROOT/private/tools/payroll_month_close.php" "$ROOT/private/ux/ActionCenter.php" "$ROOT/public_html/api/healthz.php" "$ROOT/public_html/hr/governance.php" "$ROOT/public_html/hr/_master_nav.php"; do /usr/bin/php -l "$f"; done
if grep -R "/home/u297334112" "$ROOT/private/governance" "$ROOT/private/cron/governance_guard.php" "$ROOT/private/cron/governance_config_backup.php" "$ROOT/public_html/api/healthz.php" "$ROOT/public_html/hr/governance.php" 2>/dev/null; then echo "Hardcoded production home path found in P2 runtime" >&2; exit 1; fi

echo "[7/11] Create initial config backup..."
MERLY_ROOT="$ROOT" /usr/bin/php "$ROOT/private/tools/governance_backup.php" --actor=INSTALLER --reason="P2 initial snapshot" >/tmp/merly_p2_backup.txt
cat /tmp/merly_p2_backup.txt
rm -f /tmp/merly_p2_backup.txt

echo "[8/11] Self-test governance runtime..."
MERLY_ROOT="$ROOT" /usr/bin/php "$PKG/private/tools/p2_selftest.php"

echo "[9/11] Initial payroll governance scan (best effort)..."
if MERLY_ROOT="$ROOT" /usr/bin/php "$ROOT/private/cron/governance_guard.php"; then :; else echo "WARN: initial Lark scan failed; scheduled governance_guard will retry automatically."; fi

echo "[10/11] Health snapshot..."
MERLY_ROOT="$ROOT" /usr/bin/php -r 'require getenv("MERLY_ROOT")."/private/governance/Health.php"; $h=MerlyHealth::snapshot(); echo "HEALTH SCORE ".$h["score"]."/100 ".$h["status"].PHP_EOL;'

echo "[11/11] Success + cleanup..."
echo "CORE V3 P2 INSTALL OK"
echo "- common hash-chained audit log enabled"
echo "- payroll lock/source version guard every 10 minutes"
echo "- daily config backup at 03:20 via existing Job Runner"
echo "- restore requires explicit CLI --commit and makes pre-restore backup"
echo "- public external uptime endpoint: /api/healthz.php"
echo "- admin governance UI: /hr/governance.php"
echo "- P0/P1 architecture and single Hostinger cron unchanged"
echo "Backup: $BACK"
cd "$ROOT"
rm -f merly-hr-core-v3-p2.zip
rm -rf merly-hr-core-v3-p2
BACKED=0
trap - EXIT INT TERM
echo "CLEANUP OK"
