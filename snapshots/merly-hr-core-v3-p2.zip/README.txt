MERLY HR CORE V3 - P2 GOVERNANCE
================================

P2 consolidates governance into the existing Core v3 architecture. It does not add a Hostinger cron.

Included:
1. Common append-only audit log with SHA-256 hash chain.
2. Payroll lock/version governance:
   - authorized lock creates a source/payroll snapshot version;
   - unlock requires a reason and is audited;
   - guard detects PAYROLL_CHANGED_AFTER_LOCK, SOURCE_CHANGED_AFTER_LOCK and lock-state changes outside workflow;
   - paid transition is accepted and re-baselined without incrementing the lock version.
3. Health Score (0-100): Job Runner, Core Guardian, Governance Guard, Queue, Audit, Config Backup, Payroll Governance.
4. Public external uptime endpoint: /api/healthz.php (no secrets/internal paths).
5. Automatic configuration snapshots daily at 03:20 through existing Job Runner.
6. Safe restore CLI: checksum validation, PHP syntax parse, pre-restore backup, explicit --commit.
7. Admin Governance UI: /hr/governance.php.
8. Action Center surfaces degraded/critical Health Score.

Important operational rules:
- Continue using private/tools/payroll_lock_month.php, payroll_unlock_month.php, payroll_mark_paid.php, payroll_month_close.php. P2 replaces these entrypoints with governance-aware wrappers.
- Direct manual edits to locked payroll/source data are not silently accepted. The guard raises a violation.
- Restore is CLI-only by design.

Manual backup:
  /usr/bin/php private/tools/governance_backup.php --actor=ADMIN --reason="before config change"

List backup IDs:
  ls -1 private/governance/config_backups

Restore dry-run:
  /usr/bin/php private/tools/governance_restore.php --backup=BACKUP_ID

Restore commit:
  /usr/bin/php private/tools/governance_restore.php --backup=BACKUP_ID --commit --actor=ADMIN --reason="restore approved config"

External uptime monitor target:
  https://lark.merly.cloud/api/healthz.php
Recommended interval: 5 minutes. Alert on HTTP 503 or timeout.
