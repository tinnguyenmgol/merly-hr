<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/core/bootstrap.php';
require_once dirname(__DIR__).'/core/AuditLog.php';

final class MerlyConfigVault
{
    public static function policy(): array { $f=MerlyCore::path('private/governance/policy.php');$p=is_file($f)?require $f:[];return is_array($p)?$p:[]; }
    public static function baseDir(): string { return MerlyCore::ensureDir('private/governance/config_backups'); }

    public static function create(string $actor='SYSTEM', string $reason='scheduled'): array
    {
        $policy=self::policy();$paths=$policy['backup']['paths']??[];$id=MerlyCore::now()->format('Ymd_His').'-'.bin2hex(random_bytes(3));$dir=self::baseDir().'/'.$id;
        if(!@mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Không tạo được config backup.');
        $files=[];
        foreach($paths as$rel){$rel=ltrim((string)$rel,'/');$src=MerlyCore::path($rel);if(!is_file($src))continue;$dest=$dir.'/'.$rel;if(!is_dir(dirname($dest))&&!@mkdir(dirname($dest),0700,true)&&!is_dir(dirname($dest)))throw new RuntimeException('Không tạo được thư mục backup.');if(!@copy($src,$dest))throw new RuntimeException('Không backup được '.$rel);@chmod($dest,0600);$files[$rel]=hash_file('sha256',$dest);}
        $manifest=['id'=>$id,'created_at'=>MerlyCore::now()->format(DateTimeInterface::ATOM),'actor'=>$actor,'reason'=>$reason,'files'=>$files];
        @file_put_contents($dir.'/manifest.json',json_encode($manifest,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);@chmod($dir.'/manifest.json',0600);
        self::prune((int)($policy['backup']['keep_days']??30));
        MerlyAuditLog::write('config.backup.created',['actor'=>$actor,'backup_id'=>$id,'reason'=>$reason,'file_count'=>count($files)]);
        return $manifest;
    }

    public static function list(int $limit=20): array
    {
        $dirs=glob(self::baseDir().'/*',GLOB_ONLYDIR)?:[];rsort($dirs,SORT_STRING);$out=[];
        foreach(array_slice($dirs,0,max(1,$limit))as$d){$m=json_decode((string)@file_get_contents($d.'/manifest.json'),true);if(is_array($m))$out[]=$m;}
        return$out;
    }

    public static function latestAge(): ?int { $l=self::list(1);if(!$l)return null;$ts=strtotime((string)($l[0]['created_at']??''));return$ts===false?null:max(0,time()-$ts); }

    public static function restore(string $id,bool $commit,string $actor='SYSTEM',string $reason='manual restore'): array
    {
        if(!preg_match('/^\d{8}_\d{6}-[a-f0-9]{6}$/',$id))throw new InvalidArgumentException('Backup ID không hợp lệ.');$dir=self::baseDir().'/'.$id;$mf=$dir.'/manifest.json';if(!is_file($mf))throw new RuntimeException('Không tìm thấy backup.');$m=json_decode((string)file_get_contents($mf),true);if(!is_array($m)||empty($m['files']))throw new RuntimeException('Manifest backup không hợp lệ.');
        foreach($m['files']as$rel=>$hash){$src=$dir.'/'.$rel;if(!is_file($src)||hash_file('sha256',$src)!==$hash)throw new RuntimeException('Checksum sai: '.$rel);if(str_ends_with($rel,'.php')){$out=[];$rc=0;exec_disabled_safe_lint($src,$out,$rc);if($rc!==0)throw new RuntimeException('PHP syntax backup lỗi: '.$rel);}}
        if(!$commit)return['backup_id'=>$id,'commit'=>false,'would_restore'=>array_keys($m['files'])];
        $pre=self::create($actor,'pre-restore '.$id);
        foreach($m['files']as$rel=>$hash){$src=$dir.'/'.$rel;$dst=MerlyCore::path($rel);if(!is_dir(dirname($dst)))@mkdir(dirname($dst),0700,true);$tmp=$dst.'.restoretmp';if(!@copy($src,$tmp))throw new RuntimeException('Không stage restore '.$rel);@chmod($tmp,0600);if(!@rename($tmp,$dst))throw new RuntimeException('Không commit restore '.$rel);}
        MerlyAuditLog::write('config.restore.committed',['actor'=>$actor,'backup_id'=>$id,'pre_restore_backup'=>$pre['id']??'','reason'=>$reason]);
        return['backup_id'=>$id,'commit'=>true,'restored'=>array_keys($m['files']),'pre_restore_backup'=>$pre['id']??''];
    }

    private static function prune(int $days):void{$cut=time()-max(1,$days)*86400;foreach(glob(self::baseDir().'/*',GLOB_ONLYDIR)?:[]as$d){if((filemtime($d)?:0)>=$cut)continue;self::rmTree($d);}}
    private static function rmTree(string$d):void{if(!is_dir($d))return;foreach(scandir($d)?:[]as$x){if($x==='.'||$x==='..')continue;$p=$d.'/'.$x;is_dir($p)?self::rmTree($p):@unlink($p);}@rmdir($d);}
}

if(!function_exists('exec_disabled_safe_lint')){
function exec_disabled_safe_lint(string$file,array&$out,int&$rc):void{
    // Hostinger may disable exec; runtime restore therefore uses tokenizer as the safe syntax gate.
    $code=(string)file_get_contents($file);$out=[];$rc=0;
    try{token_get_all($code,TOKEN_PARSE);}catch(ParseError$e){$out[]=$e->getMessage();$rc=1;}
}}
