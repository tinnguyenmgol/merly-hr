<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/core/bootstrap.php';
require_once dirname(__DIR__).'/core/Queue.php';
require_once __DIR__.'/ConfigVault.php';
require_once __DIR__.'/PayrollGovernance.php';

final class MerlyHealth
{
    public static function snapshot():array
    { $p=MerlyConfigVault::policy();$hp=$p['health']??[];$checks=[];$score=100;
      $job=MerlyCore::path('private/jobs/logs/job_runner.log');$age=self::age($job);$ok=$age!==null&&$age<=(int)($hp['job_runner_max_age']??900);$checks['job_runner']=['ok'=>$ok,'age_seconds'=>$age,'label'=>'Job Runner'];if(!$ok)$score-=30;
      $guardian=MerlyCore::path('private/core/state/guardian.json');$age=self::age($guardian);$ok=$age!==null&&$age<=(int)($hp['guardian_max_age']??3600);$checks['core_guardian']=['ok'=>$ok,'age_seconds'=>$age,'label'=>'Core Guardian'];if(!$ok)$score-=20;
      $guard=MerlyCore::path('private/governance/state/guard.json');$age=self::age($guard);$ok=$age!==null&&$age<=(int)($hp['governance_guard_max_age']??1800);$checks['governance_guard']=['ok'=>$ok,'age_seconds'=>$age,'label'=>'Governance Guard'];if(!$ok)$score-=10;
      $q=MerlyQueue::counts();$ok=($q['dead']??0)===0;$checks['queue']=['ok'=>$ok,'counts'=>$q,'label'=>'Core Queue'];if(!$ok)$score-=20;elseif(($q['pending']??0)>20)$score-=5;
      $adir=MerlyCore::ensureDir('private/governance/audit');$ok=is_writable($adir);$checks['audit']=['ok'=>$ok,'label'=>'Audit Log'];if(!$ok)$score-=10;
      $bage=MerlyConfigVault::latestAge();$ok=$bage!==null&&$bage<=(int)($hp['config_backup_max_age']??172800);$checks['config_backup']=['ok'=>$ok,'age_seconds'=>$bage,'label'=>'Config Backup'];if(!$ok)$score-=10;
      $viol=[];try{$viol=(new MerlyPayrollGovernance())->violations();}catch(Throwable){}$ok=count($viol)===0;$checks['payroll_governance']=['ok'=>$ok,'violations'=>count($viol),'label'=>'Payroll Governance'];if(!$ok)$score-=20;
      $score=max(0,min(100,$score));$healthy=(int)($hp['healthy_score']??80);$degraded=(int)($hp['degraded_score']??60);$status=$score>=$healthy?'healthy':($score>=$degraded?'degraded':'critical');return['status'=>$status,'score'=>$score,'time'=>MerlyCore::now()->format(DateTimeInterface::ATOM),'checks'=>$checks,'version'=>'3.2.0']; }
    private static function age(string$f):?int{return is_file($f)?max(0,time()-(filemtime($f)?:time())):null;}
}
