<?php
declare(strict_types=1);
return [
    'schema_version' => 1,
    'policy_version' => '2026.09-p2',
    'health' => [
        'healthy_score' => 80,
        'degraded_score' => 60,
        'job_runner_max_age' => 900,
        'guardian_max_age' => 3600,
        'governance_guard_max_age' => 1800,
        'config_backup_max_age' => 172800,
    ],
    'payroll' => [
        'locked_statuses' => ['Đã khóa','Đã trả'],
        'unlock_reason_min_length' => 5,
        'ignore_payroll_fields' => ['Cập nhật lúc','Ngày chuyển khoản','Mã giao dịch/UNC','Ghi chú chuyển khoản','Người xác nhận chuyển','Trạng thái chuyển khoản','Trạng thái thanh toán','Ngày trả lương'],
        'ignore_source_fields' => ['Cập nhật lúc','Updated At','Ngày cập nhật'],
    ],
    'backup' => [
        'keep_days' => 30,
        'paths' => [
            'private/config.php',
            'private/jobs/jobs_config.php',
            'private/governance/policy.php',
        ],
    ],
];
