<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/governance/ConfigVault.php';
try{$r=MerlyConfigVault::create('SYSTEM/JOB','daily');echo'CONFIG BACKUP OK '.json_encode(['id'=>$r['id']??'','files'=>count($r['files']??[])],JSON_UNESCAPED_UNICODE)."\n";}catch(Throwable$e){fwrite(STDERR,'CONFIG BACKUP FAIL '.$e->getMessage()."\n");exit(1);}
