<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/governance/PayrollGovernance.php';
require_once dirname(__DIR__).'/core/AuditLog.php';
$month=MerlyCore::month();foreach($argv??[]as$a)if(preg_match('/^20\d{2}-(0[1-9]|1[0-2])$/',$a))$month=$a;
try{$r=(new MerlyPayrollGovernance())->scan($month);MerlyAuditLog::write('governance.guard.checked',['month'=>$month,'violations'=>count($r['violations']??[]),'checked'=>$r['checked']??0]);echo'GOVERNANCE GUARD OK '.json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";exit(0);}catch(Throwable$e){MerlyAuditLog::write('governance.guard.error',['error'=>$e->getMessage()]);fwrite(STDERR,'GOVERNANCE GUARD FAIL '.$e->getMessage()."\n");exit(1);}
