<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/core/BaseRepository.php';
require_once dirname(__DIR__).'/core/Schema.php';
require_once dirname(__DIR__).'/core/Consistency.php';
require_once dirname(__DIR__).'/core/Queue.php';
require_once __DIR__.'/Status.php';
require_once dirname(__DIR__).'/governance/Health.php';

final class MerlyActionCenter
{
    private MerlyBaseRepository $repo;
    public function __construct(?MerlyBaseRepository $repo=null){$this->repo=$repo??new MerlyBaseRepository();}

    public function snapshot(array $user,string $month): array
    {
        $role=(string)($user['role']??'Employee');$isAdmin=!empty($user['is_admin'])||$role==='Admin';$isManager=$isAdmin||!empty($user['is_manager'])||$role==='Manager';
        $actorCode=(string)($user['employee_code']??$user['code']??'');
        $employees=$this->repo->records(MerlySchema::tableId('EMPLOYEES'),45);
        $empMap=[];$actorGroup='';$active=[];
        foreach($employees as $r){$f=$r['fields']??[];$code=self::s($f['Mã nhân viên']??'');if($code==='')continue;$group=self::group($f);$empMap[$code]=['fields'=>$f,'name'=>self::employeeName($f),'group'=>$group];if($code===$actorCode)$actorGroup=$group;if(self::active($f))$active[$code]=true;}
        $scope=function(string $code)use($isAdmin,$isManager,$actorCode,$actorGroup,$empMap):bool{if($isAdmin)return true;if($isManager)return $actorGroup!==''&&(($empMap[$code]['group']??'')===$actorGroup);return $code===$actorCode;};
        $tasks=[];$quick=[];$stats=['urgent'=>0,'warning'=>0,'info'=>0,'done'=>0];
        $add=function(string $severity,string $title,string $detail,string $url,string $category,string $code='')use(&$tasks,&$stats){$tasks[]=['severity'=>$severity,'title'=>$title,'detail'=>$detail,'url'=>$url,'category'=>$category,'employee_code'=>$code];if(isset($stats[$severity]))$stats[$severity]++;};

        foreach($empMap as $code=>$e){if(!$scope($code))continue;$f=$e['fields'];$onb=self::s($f['Trạng thái onboarding']??'');
            if($onb!==''&&!str_contains(mb_strtolower($onb,'UTF-8'),'hoàn tất')){
                if($isAdmin&&str_contains(mb_strtolower($onb,'UTF-8'),'hr'))$add('urgent','Duyệt hồ sơ '.$e['name'],$onb,'/hr/onboarding_admin.php','Onboarding',$code);
                elseif($code===$actorCode)$add('warning','Hoàn tất hồ sơ nhân viên',$onb,'/hr/onboarding.php','Onboarding',$code);
                elseif($isManager)$add('warning',$e['name'].' chưa hoàn tất onboarding',$onb,'/hr/onboarding_admin.php','Onboarding',$code);
            }
        }

        $payRows=$this->repo->records(MerlySchema::tableId('PAYROLL'),45);$payBy=[];
        foreach($payRows as $r){$f=$r['fields']??[];$code=self::s($f['Mã nhân viên']??'');if($code===''||self::month($f)!==$month)continue;$payBy[$code]=['record_id'=>(string)($r['record_id']??''),'fields'=>$f];}
        if($isAdmin){
            foreach($active as $code=>$_){$e=$empMap[$code]??null;if(!$e)continue;if(!isset($payBy[$code])){$add('urgent','Thiếu bảng lương '.$e['name'],'Nhân viên đang làm nhưng chưa có PAYROLL kỳ '.$month,'/hr/accounting.php?month='.$month,'Payroll',$code);continue;}
                $f=$payBy[$code]['fields'];$ps=self::s($f['Trạng thái bảng lương']??$f['Trạng thái']??'');$ready=self::payReady($ps);
                if(!$ready)$add('warning','Bảng lương chưa sẵn sàng · '.$e['name'],MerlyStatus::label($ps),'/hr/accounting.php?month='.$month,'Payroll',$code);
                $bank=self::s($e['fields']['Ngân hàng']??'');$acc=self::s($e['fields']['Số tài khoản ngân hàng']??$e['fields']['Số tài khoản']??'');if($bank===''||$acc==='')$add('urgent','Thiếu tài khoản nhận lương · '.$e['name'],'Cần bổ sung ngân hàng và số tài khoản trước khi chuyển lương.','/hr/accounting.php?month='.$month,'Accounting',$code);
            }
        }

        $events=$this->repo->records(MerlySchema::tableId('RESPONSIBILITY_EVENTS'),45);
        foreach($events as $r){$f=$r['fields']??[];if(self::s($f['Kỳ']??'')!==$month||self::s($f['Đã xoá']??'Không')==='Có')continue;$code=self::s($f['Mã nhân viên']??'');if($code===''||!$scope($code))continue;$name=$empMap[$code]['name']??$code;$admin=self::s($f['Admin duyệt']??'Chờ');$mgr=self::s($f['Quản lý duyệt']??'Chờ');$seen=self::s($f['Nhân viên đã xem']??'Chưa');$type=self::s($f['Loại']??'Ghi nhận');
            if($isAdmin&&$admin!=='Đã duyệt')$add('warning','Ghi nhận chờ Admin duyệt · '.$name,$type,'/hr/responsibility.php?month='.$month,'Trách nhiệm',$code);
            elseif($isManager&&!$isAdmin&&$mgr!=='Đã duyệt')$add('warning','Ghi nhận cần quản lý xác nhận · '.$name,$type,'/hr/responsibility.php?month='.$month,'Trách nhiệm',$code);
            elseif(!$isManager&&$code===$actorCode&&$seen!=='Đã xem')$add('info','Bạn có ghi nhận mới',$type,'/hr/responsibility.php?month='.$month,'Trách nhiệm',$code);
        }

        if($isAdmin){$q=MerlyQueue::counts();if(($q['dead']??0)>0)$add('urgent','Có '.$q['dead'].' tác vụ hệ thống lỗi','Mở Trung tâm điều hành để kiểm tra queue dead.','/hr/control-center.php','Hệ thống');elseif(($q['pending']??0)>10)$add('warning','Hàng đợi đang có '.$q['pending'].' tác vụ','Core Worker sẽ tiếp tục xử lý tự động.','/hr/control-center.php','Hệ thống');}

        if($isAdmin){try{$h=MerlyHealth::snapshot();if(($h['status']??'healthy')==='critical')$add('urgent','Health Score '.$h['score'].'/100','Governance đang phát hiện vấn đề cần xử lý.','/hr/governance.php','Governance');elseif(($h['status']??'healthy')==='degraded')$add('warning','Health Score '.$h['score'].'/100','Một số kiểm tra hệ thống cần theo dõi.','/hr/governance.php','Governance');}catch(Throwable $e){$add('warning','Không đọc được Health Score','Mở Governance để kiểm tra.','/hr/governance.php','Governance');}}

        usort($tasks,function($a,$b){$w=['urgent'=>0,'warning'=>1,'info'=>2,'done'=>3];return($w[$a['severity']]??9)<=>($w[$b['severity']]??9);});
        $quick=$isAdmin?[
            ['label'=>'Việc cần xử lý','url'=>'/hr/action-center.php','icon'=>'✓'],['label'=>'Chuyển lương','url'=>'/hr/accounting.php?month='.$month,'icon'=>'₫'],['label'=>'Ghi nhận','url'=>'/hr/responsibility.php?month='.$month,'icon'=>'!'],['label'=>'Onboarding','url'=>'/hr/onboarding_admin.php','icon'=>'◎'],['label'=>'Dashboard','url'=>'/hr/dashboard.php?view=admin','icon'=>'▦'],['label'=>'Governance','url'=>'/hr/governance.php','icon'=>'◈'],['label'=>'Hệ thống','url'=>'/hr/control-center.php','icon'=>'◇']
        ]:($isManager?[
            ['label'=>'Việc của nhóm','url'=>'/hr/action-center.php','icon'=>'✓'],['label'=>'Ghi nhận','url'=>'/hr/responsibility.php?month='.$month,'icon'=>'!'],['label'=>'Dashboard nhóm','url'=>'/hr/dashboard.php?view=manager','icon'=>'▦'],['label'=>'Của tôi','url'=>'/hr/dashboard.php?view=me','icon'=>'◉']
        ]:[
            ['label'=>'Của tôi','url'=>'/hr/dashboard.php?view=me','icon'=>'◉'],['label'=>'Ghi nhận của tôi','url'=>'/hr/responsibility.php?month='.$month,'icon'=>'✓'],['label'=>'Hồ sơ','url'=>'/hr/onboarding.php','icon'=>'□'],['label'=>'Hướng dẫn','url'=>'/hr/help.php','icon'=>'?']
        ]);
        return ['role'=>$role,'is_admin'=>$isAdmin,'is_manager'=>$isManager,'actor_code'=>$actorCode,'actor_group'=>$actorGroup,'tasks'=>$tasks,'stats'=>$stats,'quick'=>$quick,'active_employees'=>count($active),'month'=>$month];
    }

    private static function s(mixed $v):string{return MerlyBaseRepository::scalar($v);}    
    private static function employeeName(array $f):string{return self::s($f['Nhân Viên']??$f['Nhân viên']??$f['Tên nhân viên']??$f['Họ tên']??'');}
    private static function group(array $f):string{return self::s($f['Nhân Viên.Department']??$f['Bộ phận']??$f['Department']??'');}
    private static function active(array $f):bool{$s=mb_strtolower(self::s($f['Trạng thái nhân sự']??$f['Trạng thái']??'Đang làm'),'UTF-8');$calc=mb_strtolower(self::s($f['Tính lương']??'Có'),'UTF-8');return !str_contains($s,'đã nghỉ')&&!str_contains($s,'nghỉ việc')&&!in_array($calc,['không','no','false','0'],true);}
    private static function month(array $f):string{$key=self::s($f['Khóa kỳ']??$f['Khoá kỳ']??'');if(preg_match('/(20\d{2}-\d{2})/',$key,$m))return$m[1];$v=$f['Tháng lương']??null;if(is_numeric($v)){$n=(float)$v;if($n>100000000000)$n/=1000;return date('Y-m',(int)$n);}if(is_string($v)&&preg_match('/^(20\d{2}-\d{2})/',$v,$m))return$m[1];return'';}
    private static function payReady(string $s):bool{$l=mb_strtolower($s,'UTF-8');return str_contains($l,'đã khóa')||str_contains($l,'đã trả');}
}
