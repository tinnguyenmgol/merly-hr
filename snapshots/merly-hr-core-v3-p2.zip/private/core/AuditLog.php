<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

final class MerlyAuditLog
{
    public static function write(string $event, array $context = []): void
    {
        $row = [
            'time' => MerlyCore::now()->format(DateTimeInterface::ATOM),
            'event' => $event,
            'actor' => self::actor($context),
            'source' => (string)($context['source'] ?? self::source()),
            'request_id' => (string)($context['request_id'] ?? self::requestId()),
            'context' => self::sanitize($context),
        ];
        self::appendCommon($row);
        self::appendLegacy($row);
    }

    public static function record(string $action, string $targetType, string $targetId, array $before = [], array $after = [], array $meta = []): void
    {
        $changed = array_values(array_unique(array_merge(array_keys($before), array_keys($after))));
        $changed = array_values(array_filter($changed, static fn($k) => self::canon($before[$k] ?? null) !== self::canon($after[$k] ?? null)));
        self::write('governance.change', array_merge($meta, [
            'action' => $action,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'changed_keys' => $changed,
            'before_hash' => self::hash($before),
            'after_hash' => self::hash($after),
        ]));
    }

    private static function appendCommon(array $row): void
    {
        $dir = MerlyCore::ensureDir('private/governance/audit');
        $file = $dir . '/audit.jsonl';
        $lockPath = $dir . '/audit.lock';
        $lock = @fopen($lockPath, 'c+');
        if (!$lock) return;
        try {
            if (!flock($lock, LOCK_EX)) return;
            $stateFile = $dir . '/chain.json';
            $state = is_file($stateFile) ? json_decode((string)@file_get_contents($stateFile), true) : [];
            $prev = is_array($state) ? (string)($state['last_hash'] ?? '') : '';
            $row['prev_hash'] = $prev;
            $row['row_hash'] = hash('sha256', self::canon($row));
            @file_put_contents($file, json_encode($row, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND|LOCK_EX);
            @chmod($file, 0600);
            @file_put_contents($stateFile, json_encode(['last_hash'=>$row['row_hash'],'updated_at'=>$row['time']], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), LOCK_EX);
            @chmod($stateFile, 0600);
            flock($lock, LOCK_UN);
        } finally { fclose($lock); }
    }

    private static function appendLegacy(array $row): void
    {
        $dir = MerlyCore::ensureDir('private/core/logs');
        @file_put_contents($dir . '/core-audit.jsonl', json_encode($row, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND|LOCK_EX);
    }

    private static function actor(array $context): string
    {
        foreach (['actor','employee_code','uid','user_id'] as $k) if (!empty($context[$k])) return (string)$context[$k];
        return PHP_SAPI === 'cli' ? 'SYSTEM/CLI' : 'SYSTEM/WEB';
    }

    private static function source(): string
    {
        if (PHP_SAPI === 'cli') return 'cli:' . basename((string)($_SERVER['SCRIPT_NAME'] ?? 'php'));
        return 'web:' . (string)($_SERVER['REQUEST_URI'] ?? '/');
    }

    private static function requestId(): string
    {
        static $id = null;
        if ($id !== null) return $id;
        $incoming = trim((string)($_SERVER['HTTP_X_REQUEST_ID'] ?? ''));
        return $id = ($incoming !== '' ? substr($incoming, 0, 100) : bin2hex(random_bytes(8)));
    }

    private static function hash(array $v): string { return hash('sha256', self::canon($v)); }
    private static function canon(mixed $v): string
    {
        if (is_array($v)) { ksort($v); foreach ($v as $k=>$x) $v[$k] = self::canonValue($x); }
        return (string)json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
    }
    private static function canonValue(mixed $v): mixed
    {
        if (!is_array($v)) return $v;
        if (array_is_list($v)) return array_map([self::class,'canonValue'],$v);
        ksort($v); foreach($v as $k=>$x)$v[$k]=self::canonValue($x); return $v;
    }
    private static function sanitize(mixed $v): mixed
    {
        if (!is_array($v)) return $v;
        $out=[];
        foreach ($v as $k=>$x) {
            $key=(string)$k;
            if (preg_match('/secret|token|cookie|password|authorization|app_secret|encrypt_key/i',$key)) { $out[$key]='***'; continue; }
            $out[$key]=self::sanitize($x);
        }
        return $out;
    }
}
